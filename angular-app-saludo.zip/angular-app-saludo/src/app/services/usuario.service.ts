import { LoginForm } from './../interfaces/login-form.interface';
import { Usuario } from '../models/usuario.model';
import { catchError, map, tap } from 'rxjs/operators';
import { environment } from './../../environments/environment';
import { Observable, of, throwError } from 'rxjs';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, NgZone } from "@angular/core";

const base_url = environment.base_url;
const user = localStorage.getItem('user');

@Injectable({
    providedIn: 'root'
})
export class UsuarioService {

    private _usuario: Usuario;
    private _token: string;

    public auth2: any;
    public validado: boolean;

    constructor(private http: HttpClient,
        private router: Router) { }

        public get token():string {
            if (this._token != null) {
                return this._token;
            } else if(this._token == null && sessionStorage.getItem('token') != null ){
                this._token = sessionStorage.getItem('token');
                return this._token;
            }
            return null;
        }

    login(formData: LoginForm) {
        this.validado = true;
        return this.http.post(`${base_url}/login`, formData)
            .pipe(
                tap((resp: any) => {
                    console.log('token ', resp.token);
                    sessionStorage.setItem('token', resp.token);
                })
            );
    }

    LoginOauth2(formData: LoginForm)
    : Observable<any>
    {
        const url = environment.base_url_token;
        const credenciales = btoa(environment.usuario_cliente + ':' + environment.usuario_password);
        const httpHeaders = new HttpHeaders({
            'Content-Type':'application/x-www-form-urlencoded'
        ,'Authorization':'Basic '+credenciales});
        let params = `grant_type=password&username=${formData.username}&password=${formData.password}`;

        return this.http.post<any>(url, params, {headers: httpHeaders}).pipe(
            catchError(e => {
            return throwError(e);
        }));

    }

    loginPublicador(usuario: Usuario, intentos: any) {
        let numIntentos = Number(intentos);
        const url = `${base_url}/sesion/iniciarSesion/${numIntentos}`;
        return this.http.post<any>(url, usuario)
        .pipe(catchError(e => {
            return throwError(e);
        }));
    }

    inactivarUsuario(usuario: Usuario) {
        const url = `${base_url}/sesion/inactivarUsuario`;
        return this.http.post<any>(url, usuario)
        .pipe(catchError(e => {
            return throwError(e);
        }));
    }

    logout() {
        sessionStorage.removeItem('token');
        this.auth2.signOuth().then(() => {
            this.router.navigateByUrl('/login');
        })
    }

    validarToken(): boolean {
        this._token = sessionStorage.getItem('token');
        let payload = this.obtenerDatosToken();

        if (payload && payload !== null && payload.user_name ) {
            this.validado = true;
        } else {
            this.validado = false;
        }
        return this.validado;
    }

    guardarToken(accessToken: string){
        this._token = accessToken;
        sessionStorage.setItem('token',accessToken);
    }

    guardarRol(rol: string){
        sessionStorage.setItem('rol', rol);
    }
    guardarToken2(accessToken: string){
        this._token = accessToken;
        sessionStorage.setItem('token',accessToken);
    }

    guardarExpiracion(exp: any){
        sessionStorage.setItem('exp', exp);
    }

    obtenerDatosToken():any{
        let accessToken = sessionStorage.getItem('token');
        if (accessToken && accessToken !== null) {
            return JSON.parse(atob(accessToken.split(".")[1]));
        }
    }
}
