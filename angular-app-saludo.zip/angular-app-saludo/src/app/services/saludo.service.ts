import { Injectable, NgZone } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Observable, of, throwError } from 'rxjs';
import { tap, map, catchError } from 'rxjs/operators';

import { environment } from '../../environments/environment';


const base_url = environment.base_url;
@Injectable({
    providedIn: 'root'
})

export class SaludoService {


    constructor(private http: HttpClient) { }


    cargarSaludoEspanolPorNombre(nombre: string) {
        const url = `${base_url}/saludo/espanol/${nombre}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response)
            );
    }

    cargarSaludoInglesPorNombre(nombre: string) {
        const url = `${base_url}/saludo/ingles/${nombre}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response)
            );
    }

    cargarSaludoFrancesPorNombre(nombre: string) {
        const url = `${base_url}/saludo/frances/${nombre}`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response)
            );
    }

    cargarUsuarios() {
        const url = `${base_url}/saludo/usuarios`;
        return this.http.get(url)
            .pipe(
                map((response: any) => response)
            );
    }

    


}
