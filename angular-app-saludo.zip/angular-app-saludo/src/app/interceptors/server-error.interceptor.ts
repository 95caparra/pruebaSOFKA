import { Injectable } from '@angular/core';
import {
  HttpEvent, HttpRequest, HttpHandler,
  HttpInterceptor, HttpErrorResponse
} from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { connectableObservableDescriptor } from 'rxjs/internal/observable/ConnectableObservable';
import { Usuario } from '../models/usuario.model';
import { UsuarioService } from '../services/usuario.service';

@Injectable()
export class ServerErrorInterceptor implements HttpInterceptor {
  constructor(
    private router: Router,
    private usuarioService: UsuarioService
  ) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    return next.handle(request).pipe(
      retry(1),
      catchError((error: HttpErrorResponse) => {
        let mensaje: string;
        let titulo: string;
        if (error.status !== 200) {
          if (error.error.error === 'invalid_token') {
            titulo = 'Aviso';
            mensaje = 'La sesión ha expirado';
            Swal.fire({
              title: titulo,
              html: mensaje
            }).then((result) => {
              /* Read more about handling dismissals below */
              let usuario = new Usuario();
              let username = sessionStorage.getItem('usuario');

              localStorage.clear();
              sessionStorage.clear();
              this.router.navigateByUrl('/login');
            });
          } else if (error.error.error === 'invalid_grant'
            && error.error.error_description === 'User is disabled') {
            titulo = 'Información';
            mensaje = 'Usuario inactivo, por favor comuníquese con el administrador del sistema';
            Swal.fire({
              title: titulo,
              html: mensaje
            }).then((result) => {
              /* Read more about handling dismissals below */
              if (result.dismiss === Swal.DismissReason.timer) {
                /*sessionStorage.clear();
                localStorage.clear();
                this.router.navigate(['/login']);*/
              }
            });
          } else if (error.error.error === 'invalid_grant' &&
            error.error.error_description === 'Bad credentials') {
            titulo = 'Información';
            mensaje = 'Usuario o clave incorrectos';
            Swal.fire({
              title: titulo,
              html: mensaje
            }).then((result) => {
              /* Read more about handling dismissals below */
              if (result.dismiss === Swal.DismissReason.timer) {
                /*sessionStorage.clear();
                localStorage.clear();
                this.router.navigate(['/login']);*/
              }
            });
          } else if (error.error.mensaje !== null && error.error.mensaje !== undefined) {
              Swal.fire({
                title: 'Información',
                html: error.error.mensaje
              }).then((result) => {
                
              });           
              this.router.navigateByUrl('/usuarios');

          }

        } else {
          return throwError(error);
        }
      })
    );
  }
}
