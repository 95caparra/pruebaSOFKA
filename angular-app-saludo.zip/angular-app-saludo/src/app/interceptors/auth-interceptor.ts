import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { environment } from './../../environments/environment';
import Swal from 'sweetalert2';
@Injectable({
  providedIn: 'root'
})
export class AuthInterceptorService implements HttpInterceptor {

  constructor(
    private router: Router
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let request = req;
    let valor: string;
    let token: string = sessionStorage.getItem('token');
    if (request.url.includes('consultaParametro')) {
      valor = 'consultaParametro';
    } else if (request.url.includes('inactivarUsuario')) {
      valor = 'inactivarUsuario';
    } else if (request.url.includes('cerrarSesionSinToken')) {
      valor = 'cerrarSesionSinToken';
    }

    switch (valor) {
      case 'consultaParametro':
        token = null;
        break;
      case 'inactivarUsuario':
        token = null;
        break;
      case 'cerrarSesionSinToken':
        token = null;
        break;
      default:
        if (token) {
          request = req.clone({
            setHeaders: {
              authorization: `Bearer ${token}`
            }
          });
        }
        break;
    }

    return next.handle(request).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status === 401) {
          this.router.navigateByUrl('/');
        }
        
        return throwError(err);
      })
    );
  }

}
