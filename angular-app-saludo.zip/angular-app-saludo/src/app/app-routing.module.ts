import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './auth/login/login.component';

// Modulos
import { PagesRoutingModule } from './pages/pages-routing.module';


const routes: Routes = [

  { path: '', redirectTo: '/login',  pathMatch: 'full' },
  { path: '**', component: LoginComponent },
];



@NgModule({
  imports: [
    RouterModule.forRoot( routes ),
    PagesRoutingModule,
    BrowserModule, 
  ],
  exports: [ RouterModule ]
})
export class AppRoutingModule { }
