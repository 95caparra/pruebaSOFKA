
import { environment } from './../../../environments/environment';
import { UsuarioService } from './../../services/usuario.service';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import Swal from 'sweetalert2';
import { Usuario } from './../../models/usuario.model';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public usuario: Usuario;
  public formSubmitted = false;
  public auth2: any;
  public intentos: number = 0;
  public intentos2: number = 0;
  public siteKey: string;
  public submitted = false;
  public validado: boolean = false;
  public mensajeLimite: string;
  public limiteDB: number = 0;

  public ipAddress: string;

  public loginForm = this.fb.group({
    username: ['', [Validators.required, Validators.minLength(5), Validators.maxLength(50)]],
    password: ['',],
    recaptcha: ['', [Validators.required]]
  });

  @ViewChild('alert', { static: false }) alert: ElementRef;

  constructor(private router: Router,
    private fb: FormBuilder,
    private usuarioService: UsuarioService
  ) {
    this.intentos = 0;
    this.validado = false;
  }

  /**
  * @author cochoa
  * @method Método que permite inicializar el componente
  */
  ngOnInit(): void {
    if (this.usuarioService.validarToken()) {
      this.router.navigateByUrl('');
    }
    this.usuario = new Usuario();
    this.intentos = 0;
    this.intentos2 = 0;
    this.validado = false;
    localStorage.clear();
  }
  // convenience getter for easy access to form fields
  get f() { return this.loginForm.controls; }

  /**
  * @author cochoa
  * @method Método que permite iniciar session en el sistema
  */
  login() {
    this.submitted = true;
    if (this.f.username.status === 'VALID' &&
      this.f.password.status === 'VALID') {
      console.log('loguear ...');
      this.loguear();
    }
  }

  /**
  * @author cochoa
  * @method Método que permite loguear
  */
  loguear() {
    this.validado = false;

    this.usuarioService.LoginOauth2(this.loginForm.value).subscribe(
      response => {        
        let rol;
        response.rol.forEach(element => {
          rol = element.authority;
        });
        this.router.navigateByUrl('usuarios');
        this.usuarioService.guardarToken(response.access_token);
        this.usuarioService.guardarExpiracion(response.expires_in);
        this.usuarioService.guardarRol(rol);
        sessionStorage.setItem('usuario', this.loginForm.value.username);
      });
  }

  /**
 * @author cochoa
 * @method Método que remueve alerta en html
 */
  closeAlert() {
    this.alert.nativeElement.classList.remove('show');
  }

}

