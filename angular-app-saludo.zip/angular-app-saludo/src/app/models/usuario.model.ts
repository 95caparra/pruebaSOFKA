/*
*	Archivo: usuario.model.ts
*	Fecha: 28/05/2021
*	Todos los derechos de propiedad intelectual e industrial sobre esta
*	aplicación son de propiedad exclusiva del GRUPO ASESORIA EN
*	SISTEMATIZACION DE DATOS SOCIEDAD POR ACCIONES SIMPLIFICADA – GRUPO ASD S.A.S.
*	Su uso, alteración, reproducción o modificación sin la debida
*	consentimiento por escrito de GRUPO ASD S.A.S.
*	autorización por parte de su autor quedan totalmente prohibidos.
*
*	Este programa se encuentra protegido por las disposiciones de la
*	Ley 23 de 1982 y demás normas concordantes sobre derechos de autor y
*	propiedad intelectual. Su uso no autorizado dará lugar a las sanciones
*	previstas en la Ley.
*/
export class Usuario {

    public role: string;
    public nombre: string;
    public username: string;
    public usuario: string;
    public password: string;
    public email: string;
    public img: string;

    /*constructor(
        public role: string,
        public nombre: string,
        public username: string,
        public usuario: string,
        public password: string,
        public email: string,
        public img: string
    ){}*/
}