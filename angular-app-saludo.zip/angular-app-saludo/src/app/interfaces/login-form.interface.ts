export interface LoginForm {
    username: string;
    email: string;
    password: string;
    remember: boolean;
}