import { UsuarioService } from './../services/usuario.service';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { Location } from '@angular/common';
import { Usuario } from '../models/usuario.model';

@Injectable({
    providedIn: 'root'
})

export class AuthGuard implements CanActivate {
    constructor(
        private usuarioService: UsuarioService,
        private router: Router,
        private location: Location) { }

    canActivate(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot
    ) {
        let validador = this.usuarioService.validarToken();
        if (!validador) {
            sessionStorage.clear();
            localStorage.clear();
            this.router.navigate(['/login']);
        } else if (this.tokenExpiro()) {
            validador = false;
            sessionStorage.clear();
            localStorage.clear();
            this.router.navigate(['/login']);
        }

        return validador;
    }
    
    /**
    * @author cochoa
    * @method Método que permite validar expiración token
    */
    tokenExpiro(): boolean {
        const token = this.usuarioService.obtenerDatosToken();
        let now = new Date().getTime() / 1000;
        if (token.exp < now) {
            return true;
        }
        return false;
    }

}