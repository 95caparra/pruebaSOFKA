import { Usuario } from './../../models/usuario.model';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SaludoService } from 'src/app/services/saludo.service';
import Swal from 'sweetalert2';
import { UsuarioService } from 'src/app/services/usuario.service';

@Component({
  selector: 'app-usuarios',
  templateUrl: './usuarios.component.html',
  styleUrls: ['./usuarios.component.css']
})
export class UsuariosComponent implements OnInit {

  public cargando: boolean = true;
  public total: number = 0;

  public idiomas: any[] = [];
  public idiomaSeleccionado: string;

  public usuarios: Usuario[] = [];

  public rol: string;

  public usuario: Usuario;

  constructor(
    private saludoService: SaludoService,
    private router: Router,
    private usuarioService: UsuarioService
  ) {

  }

  ngOnInit(): void {
    this.idiomas = [];
    this.usuario = new Usuario();
    this.cargarUsuarios();
    this.cargarData();

    this.rol = sessionStorage.getItem('rol');
  }

  cargarData() {   

    let idiomaEspanolArray= {
      codigo: 'Español'      
    };

    this.idiomas.push(idiomaEspanolArray);

    let idiomaInglesArray= {
      codigo: 'Inglés' 
    };

    this.idiomas.push(idiomaInglesArray);

    let idiomaFrancessArray= {
      codigo: 'Francés' 
    };

    this.idiomas.push(idiomaFrancessArray);

    console.log('idiomas ', this.idiomas);
    
  }

  cargarUsuarios(){
    this.cargando = true;

    this.saludoService.cargarUsuarios().subscribe((data: any) => {
      console.log('usuarios ', data.objeto);    
      this.usuarios = data.objeto;   
      this.total = this.usuarios.length;  
      this.cargando = false;
    })
  }

  buscarIdioma(nombre: string) {
    this.cargando = true;
    
    if(nombre !== undefined 
      && nombre !== '' 
      && this.idiomaSeleccionado !== undefined){
      console.log('nombre ', nombre);
      console.log('idiomaSeleccionado', this.idiomaSeleccionado);

      switch (this.idiomaSeleccionado) {
        case 'Español':
          this.buscarEspanol(nombre);
          break;
        case 'Inglés':
          this.buscarIngles(nombre);
          break;
        case 'Francés':
          this.buscarFrances(nombre);
          break;
        default:
          break;
      }
    } else {
      Swal.fire(
        'Idioma y Nombre requerido',      
        'Idioma y Nombre requerido',        
        'error'
      );
      this.ngOnInit();
    }
    
  }

  buscarEspanol(nombre: string){
    this.saludoService.cargarSaludoEspanolPorNombre(nombre)
    .subscribe((data: any) => {
      
      Swal.fire(
        data.saludo,
        'correo: '+data.detalles.email,        
        'success'
      )

      this.cargando = false;
    })
  }

  buscarIngles(nombre: string){
    this.saludoService.cargarSaludoInglesPorNombre(nombre)
    .subscribe((data: any) => {
      Swal.fire(
        data.saludo,
        'correo: '+data.detalles.email,        
        'success'
      )

      this.cargando = false;
    })
  }

  buscarFrances(nombre: string){
    this.saludoService.cargarSaludoFrancesPorNombre(nombre)
    .subscribe((data: any) => {
      Swal.fire(
        data.saludo,
        'correo: '+data.detalles.email,        
        'success'
      )

      this.cargando = false;
    })
  }


  cambiarPagina(valor: number) {

  }

  cerrarSesion() {
    Swal.fire({
      title: 'Seguro?',
      text: "Desea cerrar sesión!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Aceptar!',
      cancelButtonText: 'Cancelar!'
    }).then((result) => {
      if (result.isConfirmed) {
        let username = sessionStorage.getItem('usuario');
        this.usuario.usuario = username;
        localStorage.clear();
        sessionStorage.clear();
        this.router.navigateByUrl('/login');
      }
    })
  }


}
