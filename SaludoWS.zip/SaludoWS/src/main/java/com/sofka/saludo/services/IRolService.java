package com.sofka.saludo.services;

import com.sofka.saludo.entity.Role;

public interface IRolService {
	public Role rolById(Long id);
}
